"""Read the existing course API using only the visiting user's course grant."""
from __future__ import annotations

from functools import cached_property, lru_cache
import re
import threading

import requests

from .archive import ArchiveError

BAR_FIELDS=("open","high","low","close","pre_close","pct","volume","amount")
SAFE_ERRORS=re.compile(r"[\u3400-\u9fff]")


def redeem(origin,code):
    """Exchange against the issuing origin; never store the public-facing course code in a cookie."""
    if not isinstance(code,str) or not re.fullmatch(r"[A-Za-z0-9._~-]{16,180}",code):
        return None
    try:
        with requests.post(origin+"/visit/exchange",headers={"Origin":origin},json={"code":code},allow_redirects=False,timeout=(8,18)) as reply:
            if reply.status_code in (400,401,403):return None
            if reply.status_code!=204:raise ArchiveError("课程验证服务暂时不可用，请重试。")
            return reply.cookies.get("__Host-course_view")
    except requests.RequestException as exc:
        raise ArchiveError("暂时无法连接课程验证服务，请重试。") from exc


class CourseService:
    def __init__(self,origin,code,cookie):
        self.origin=origin
        self._code=code
        self._cookie=cookie
        self._login_lock=threading.Lock()
        root=self.request("workspace")
        self.day=root["day"]
        self._valid_day(self.day)
        self.snapshot={"day":self.day,"items":root["rows"],"aliases":root.get("aliases",{})}
        self.catalog={r[0]:r for r in root["rows"]}
        self.manifest=root["progress"] or {}
        if not all(isinstance(self.manifest.get(k),int) for k in ("ready","bars")):
            raise ArchiveError("行情覆盖统计暂时不可用。")

    @staticmethod
    def _valid_day(day):
        if not isinstance(day,str) or not re.fullmatch(r"20\d{6}",day):
            raise ArchiveError("课程数据版本无效。")

    def request(self,endpoint,parameters=None,body=None):
        # Endpoints are selected by server code. The user's browser never chooses an upstream URL.
        if endpoint not in {"workspace","coverage","portfolio","series","research"}:
            raise ArchiveError("未知的课程查询类型。")
        for attempt in range(2):
            cookie=self._cookie
            try:
                with requests.request("GET" if body is None else "POST",self.origin+"/api/"+endpoint,params=parameters,json=body,
                    headers={"Origin":self.origin},cookies={"__Host-course_view":cookie},
                    timeout=(8,115),allow_redirects=False) as response:
                    if response.status_code==401 and attempt==0:
                        with self._login_lock:
                            if self._cookie==cookie:
                                new=redeem(self.origin,self._code)
                                if not new:raise ArchiveError("课程访问已失效，请重新打开专用链接。")
                                self._cookie=new
                        continue
                    if response.status_code>=400 or response.is_redirect:
                        if response.status_code==400:
                            try:msg=response.json().get("error","")
                            except ValueError:msg=""
                            if SAFE_ERRORS.search(msg):raise ArchiveError(msg[:160])
                        raise ArchiveError(f"课程服务暂时未能完成这项查询（HTTP {response.status_code}），请重试。")
                    data=response.json()
                    version=data.get("until") or data.get("day")
                    if endpoint not in {"research"} and hasattr(self,"day") and version is not None and version!=self.day:
                        raise ArchiveError("行情版本已经更新，请重新打开课程链接。")
                    return data
            except (requests.RequestException,requests.exceptions.JSONDecodeError) as exc:
                raise ArchiveError("课程数据服务连接超时或响应无效，请重试。") from exc
        raise ArchiveError("课程数据服务连接失败。")

    @lru_cache(maxsize=12)
    def series(self,code):
        if code not in self.catalog:raise ArchiveError("未知的证券代码。")
        raw=self.request("series",{"asOf":self.day,"symbol":code})
        if raw.get("instrument",{}).get("symbol")!=code or raw.get("until")!=self.day:
            raise ArchiveError("返回的证券与所选代码不一致。")
        rows=[[r["day"].replace("-",""),*(r[f] for f in BAR_FIELDS)] for r in raw["bars"]]
        return {"symbol":code,"bars":rows,"until":self.day,"status":raw["status"]}

    @cached_property
    def factors(self):
        result=self.request("workspace",{"view":"factors","asOf":self.day})["factors"]
        if result["day"]!=self.day:raise ArchiveError("因子版本不匹配。")
        return result

    @property
    def bands(self):
        return {"groups":self.factors["groups"]}

    @cached_property
    def stock_life(self):
        return {c:(r[6],r[7]) for c,r in self.catalog.items() if r[2]=="stock"}

    @cached_property
    def daily(self):
        return {"dates":[row[0] for row in self.series("000001.SH")["bars"]]}

    @lru_cache(maxsize=24)
    def coverage_page(self,kind,status,query,page):
        payload=self.request("coverage",{"kind":kind,"status":status,"q":query,"page":page})
        return payload["total"],[[r["code"],r["kind"],r["status"],r["bars"],r["first_day"],r["last_day"]] for r in payload["rows"]]

    @lru_cache(maxsize=8)
    def signal_dates(self,key,venue):
        data=self.request("workspace",{"asOf":self.day,"view":"backtest","factor":key,"exchange":venue,"count":1})
        return [(m["signal"],m["entry"],m["end"]) for m in data["periods"]]

    @lru_cache(maxsize=12)
    def details(self,kind,code,when):
        data=self.request("research",{"asOf":self.day,"type":kind,"symbol":code,"day":when})
        return data["items"] if kind=="financial" else data

    def run_range(self,r,start,end):
        spec={"model":r.model,"controlModel":r.control,"count":r.count,"fee":r.fee,"exchange":r.exchange,"bench":r.bench,
              "weighting":r.weighting,"weights":list(r.weights),"symbols":list(r.symbols),"interval":r.interval,
              "trainFrom":start,"trainTo":end}
        if r.daily:spec["intervalUnit"]=r.cadence
        payload=self.request("portfolio",body={"action":"range","asOf":self.day,"rules":spec})
        return payload["result"]
