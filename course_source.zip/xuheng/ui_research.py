from collections import Counter, defaultdict
from functools import lru_cache

import pandas as pd
import streamlit as st

from .details import extra
from .frames import BENCHMARKS,MARKETS,Rules
from .portfolio import run
from .research import codes,common_series,coverage_by_code,rolling_beta
from .ui_common import STATUS,conf,curve,dates,fmt,iso,label,option,pct,rangebars,table
from .ui_portfolio import remember_research,result

VENUE={"SSE":"上交所","SZSE":"深交所","BSE":"北交所","CSI":"中证","CNI":"国证","SW":"申万","CI":"中信","CICC":"中信","OTH":"其他"}
SCOPES={"benchmark":"基准 / 已核","equity":"境内股票指数","industry":"行业系列","review":"范围待核"}
BAR_HEADERS=["交易日","开盘","最高","最低","收盘","参考前收盘","涨跌幅（%）","成交量（手）","成交额（千元）"]
FACTORS={"mom":"60 日动量","vol":"20 日低波动","pe":"低市盈率","pb":"低市净率（PB）","turn":"换手率"}


def active(s):
    return [r for r in s.snapshot["items"] if r[2]=="stock" and r[5]=="L" and r[9] is not None]


def coverage(s):
    with st.expander("查看历史覆盖与数据权限"):
        a,b,c=st.columns(3)
        with a:kind=option("证券类别",{"":"全部","stock":"个股","index":"指数"},"cfg_covkind")
        with b:status=option("日线状态",{"":"全部",**STATUS},"cfg_covstatus")
        with c:query=st.text_input("搜索名称或代码",key="cfg_covquery").strip().lower()
        if hasattr(s,"coverage_page"):
            total,items=s.coverage_page(kind,status,query,0)
            pages=max(1,(total+11)//12)
            if pages>1:
                page=int(st.number_input("覆盖目录页码",1,pages,1,key=f"cfg_covpage_{kind}_{status}_{query}"))
                if page>1:_,items=s.coverage_page(kind,status,query,page-1)
            st.caption(f"共有 {total:,} 条符合条件的记录。不同证券从各自可用日期开始。")
        else:
            items=[r for r in s.coverage if (not kind or kind==r[1]) and (not status or status==r[2]) and (not query or query in (r[0]+" "+s.catalog[r[0]][1]).lower())]
            st.caption(f"共有 {len(items):,} 条符合条件的记录，显示前 200 条。不同证券从各自可用日期开始。")
        table([{"证券":label(s,r[0]),"状态":STATUS[r[2]],"日线数":r[3],"最早交易日":iso(r[4]),"最近交易日":iso(r[5])} for r in items[:200]])


def overview(s):
    st.title("市场总览");st.write(iso(s.day)+" 收盘 · 沪、深、北 A 股")
    stocks=active(s);rec=[r for r in stocks if r[10] is not None]
    ups=sum(r[10]>0 for r in rec);downs=sum(r[10]<0 for r in rec)
    c=st.columns(4)
    c[0].metric("当日有报价",fmt(len(stocks),0)+" 只");c[1].metric("上涨家数",fmt(ups,0));c[2].metric("下跌家数",fmt(downs,0));c[3].metric("成交额（万亿元）",fmt(sum(r[11] or 0 for r in stocks)/1e9))
    st.caption(f"当日平盘 {len(rec)-ups-downs:,} 只。")
    b=option("主要指数",BENCHMARKS,"cfg_overviewindex","000300.SH")
    bars=rangebars(s.series(b)["bars"],"cfg_overview");curve([(BENCHMARKS[b],[(r[0],r[4]) for r in bars])],"主要指数走势","收盘点位")
    groups=defaultdict(list)
    for r in rec:
        if r[4]:groups[r[4]].append(r[10])
    sector=st.selectbox("行业",["全部行业",*sorted(groups)],key="cfg_ovsector")
    c=st.columns(2)
    with c[0]:
        st.markdown("**个股涨幅前十**")
        tops=sorted((r for r in rec if sector=="全部行业" or r[4]==sector),key=lambda r:(-r[10],r[0]))[:10]
        table([{"证券":label(s,r[0]),"行业":r[4],"涨跌幅":pct(r[10])} for r in tops])
    with c[1]:
        st.markdown("**行业表现（个股等权）**")
        table([{"行业":k,"平均涨跌":pct(sum(v)/len(v)),"股票数":len(v)} for k,v in sorted(groups.items(),key=lambda t:-sum(t[1])/len(t[1]))])
    st.caption(f"行情来自 Tushare Pro，包含历史退市证券。已校验 {s.manifest['ready']:,} 个有日线的标的，共 {s.manifest['bars']:,} 条记录。")
    coverage(s)


def directory(s):
    with st.expander("浏览指数目录"):
        c,d=st.columns(2)
        with c:scope=option("指数范围",{"":"全部目录",**SCOPES},"cfg_indexscope")
        with d:query=st.text_input("搜索代码、名称或类别",key="cfg_indexquery").strip().lower()
        found=sorted((r for r in s.catalog.values() if r[2]=="index" and (not scope or scope==r[8]) and query in (" ".join(str(v or "") for v in (r[0],r[1],r[4]))).lower()),key=lambda r:(r[8]!="benchmark",r[0]))
        st.caption(f"找到 {len(found):,} 条，显示前 200 条。目录收录不代表均有行情权限。")
        records=[{"证券":label(s,r[0]),"发布市场":VENUE.get(r[3],r[3]),"类别":r[4],"范围":SCOPES.get(r[8],r[8])} for r in found[:200]]
        if not hasattr(s,"coverage_page"):
            for r,record in zip(found,records):record["日线"]=STATUS[coverage_by_code(s)[r[0]][2]]
        table(records)


def security(s,index=False):
    kind="index" if index else "stock";p="cfg_"+kind+"_";st.title("指数中心" if index else "个股研究")
    st.write("查询指数历史，并在共同交易日比较走势。" if index else "查询个股收盘行情、估值及相对市场的 120 日滚动 Beta。")
    options=codes(s,kind);default="000300.SH" if index else "600519.SH"
    code=st.selectbox("搜索指数名称或代码" if index else "搜索股票名称或代码",options,index=options.index(default),format_func=lambda c:label(s,c),key=p+"code")
    row=s.catalog[code]
    if hasattr(s,"coverage_page"):
        selected=s.series(code);history=selected["bars"]
        cov=[code,kind,selected["status"],len(history),history[0][0] if history else None,history[-1][0] if history else None]
    else:cov=coverage_by_code(s)[code]
    n=cov[3]
    st.subheader(row[1]);st.caption(f"{code}　·　{VENUE.get(row[3],row[3])}　·　{row[4] or '未分类'}　·　{('已退市 / 已终止' if row[5]=='D' else SCOPES.get(row[8],'A 股'))}")
    c=st.columns(4);c[0].metric("当日收盘",fmt(row[9]));c[1].metric("日涨跌幅",pct(row[10]))
    c[2].metric("发布日期" if index else "滚动市盈率",iso(row[6]) if index else fmt(row[12]))
    c[3].metric("成交额（亿元）" if index else "市净率（PB）",fmt(row[11]/1e5 if row[11] is not None else None) if index else fmt(row[13]))
    bars=s.series(code)["bars"] if n else []
    if not n:st.info(f"日线状态：{STATUS[cov[2]]}。")
    else:
        st.caption(f"有 {n:,} 条历史日线，{iso(cov[4])} 至 {iso(cov[5])}。")
        view=rangebars(bars,p)
        if index:
            other=option("走势对比",{"":"单独查看",**{c:v for c,v in BENCHMARKS.items() if c!=code}},p+"comp"+code)
            if other:
                pair=common_series(view,s.series(other)["bars"])
                if pair[0]:curve([(row[1],pair[0]),(BENCHMARKS[other],pair[1])],"共同交易日走势","共同起日 = 100",100)
                else:st.info("所选区间没有共同的交易日。")
            else:curve([(row[1],[(r[0],r[4]) for r in view])],"指数收盘走势","收盘点位")
        else:
            curve([(row[1],[(r[0],r[4]) for r in view])],"历史收盘走势","元 / 股（未复权）")
            bench=option("滚动 Beta 的市场基准",BENCHMARKS,p+"betabench","000300.SH")
            idx=s.series(bench)["bars"];launch=s.catalog[bench][6] or ""
            hits,points=rolling_beta(bars,[r for r in idx if r[0]>=launch])
            visible=[pair for pair in points if pair[0]>=view[0][0]]
            if visible:
                st.metric("120 日滚动 Beta",fmt(visible[-1][1],3))
                curve([("滚动 Beta",visible)],"120 日滚动 Beta","Beta",1)
            else:st.info("所选区间没有可报告的 Beta；每个估计需要 120 对有效单日收益。")
            st.caption("用同一交易日的股票与基准收益估计；基准自发布日期起纳入，个股采用参考前收盘，跳过停牌和复牌后的跨日收益。")
        with st.expander("历史记录与 CSV 导出"):
            frame=pd.DataFrame(view,columns=BAR_HEADERS);frame["交易日"]=frame["交易日"].map(iso)
            st.dataframe(frame.iloc[::-1],use_container_width=True,hide_index=True)
            st.download_button("导出所选区间 CSV",frame.to_csv(index=False).encode("utf-8-sig"),f"{code}_{view[0][0]}_{view[-1][0]}.csv","text/csv",key="download_"+kind)
    with st.expander("历史成分与权重" if index else "财务披露"):
        cutoff=dates("查询截至日期",s.day,s.day,p+"md") if index else s.day
        request=(s.day,code,cutoff)
        key=kind+"_last_extra"
        if st.button("查询最近一期成分" if index else "查看财报指标",key="extra_"+kind):
            st.session_state.pop(key,None)
            try:st.session_state[key]=(request,extra(s,"members" if index else "financial",code,cutoff,conf("TUSHARE_TOKEN")))
            except ValueError as exc:st.info(str(exc))
        if key in st.session_state and st.session_state[key][0]==request:
            data=st.session_state[key][1]
            if index:
                st.caption("最近一期成分日期："+iso(data["day"]));table([{"股票代码":c,"股票名称":name,"权重（%）":v} for c,name,v in data["items"]])
            else:table([dict(zip(["报告期","公告日","每股收益","净资产收益率（%）","毛利率（%）","资产负债率（%）"],[iso(r[0]),iso(r[1]),*r[2:]])) for r in data])
    if index:directory(s)


def factors(s):
    st.title("因子选股");st.write("在当期有报价的 A 股中按市场、行业和因子排序。")
    a,b,c=st.columns(3);stocks=active(s)
    with a:k=option("排序因子",FACTORS,"cfg_fack")
    with b:v=option("市场",MARKETS,"cfg_facv")
    with c:sector=st.selectbox("行业",["全部行业",*sorted({r[4] for r in stocks if r[4]})],key="cfg_facsec")
    sig={r[0]:r[1:] for r in s.factors["latest"]};items=[]
    for r in stocks:
        if (v and not r[0].endswith("."+v)) or (sector!="全部行业" and r[4]!=sector):continue
        val=sig.get(r[0],(None,None))[0 if k=="mom" else 1] if k in ("vol","mom") else r[{"pe":12,"pb":13,"turn":15}[k]]
        if val is not None and (k not in ("pb","pe") or val>0):items.append((val,r))
    items.sort(key=lambda t:(t[0] if k in ("vol","pb","pe") else -t[0],t[1][0]))
    st.caption(f"{iso(s.day)} 收盘 · {len(items):,} 只入选。市盈率、市净率剔除非正值；缺失因子值不参与排名。")
    if items:
        pages=(len(items)+49)//50
        pg=st.number_input("结果页码",1,pages,1,key=f"cfg_facpage_{k}_{v}_{sector}")
        off=(pg-1)*50;table([{"排名":i,"证券":label(s,r[0]),"行业":r[4],"因子值":fmt(val)+("%" if k in ("vol","mom","turn") else ""),"市值（亿元）":None if r[14] is None else round(r[14]/10000,2),"日涨跌":pct(r[10])} for i,(val,r) in enumerate(items[off:off+50],off+1)])
    if k in ("vol","mom") and sector=="全部行业":
        groups=s.bands["groups"][k+"-"+(v or "all")]
        st.subheader("分组后的下期平均收益")
        table([{"因子组":("第 1 组 · 排名靠前" if i==1 else "第 5 组 · 排名靠后" if i==5 else f"第 {i} 组"),"平均持有期收益":pct(avg),"调仓期数":n} for i,(avg,n) in enumerate(groups,1)])
        st.caption("各月末用当时已有行情选股分组，下一交易日开盘建仓；表内是各期等权持有收益的算术平均，未扣费，不是累计收益。")
        def use():
            st.session_state.update(cfg_stratmodel=k,cfg_stratvenue=v,cfg_nav="strategies")
            st.query_params["page"]="strategies"
        st.button("用此规则做策略回测",on_click=use)
    elif k=="pb":st.caption("长期历史 PB 可在「组合表现」选择低市净率，并用同一股票池比较。")


@lru_cache(maxsize=12)
def signals(s,k,v):
    if hasattr(s,"signal_dates"):return s.signal_dates(k,v)
    return [(p["signal"],p["entry"],p["end"]) for p in s.json(s.factor_index["views"][k+"-"+(v or "all")])]


def strategy(s):
    st.title("策略回测");st.write("按月末已知信息选股，下一交易日开盘等权建仓，比较扣费后的历史表现。")
    a,b,c=st.columns(3)
    with a:k=option("选股规则",{i:FACTORS[i] for i in ("mom","vol")},"cfg_stratmodel")
    with b:v=option("股票范围",MARKETS,"cfg_stratvenue")
    with c:count=int(st.number_input("持股数",1,200,30,key="cfg_stratcount"))
    bounds=signals(s,k,v);q,w=st.columns(2)
    with q:aa=dates("信号起日",bounds[0][0],s.day,"cfg_stratstart"+k+v)
    with w:zz=dates("截止日",s.day,s.day,"cfg_stratend")
    q,w=st.columns(2)
    with q:fee=st.number_input("单边费用（基点）",0.,100.,10.,step=0.5,key="cfg_stratfee")
    with w:bench=option("比较基准",BENCHMARKS,"cfg_stratbench","000300.SH")
    r=Rules(model=k,count=count,bench=bench,fee=fee,exchange=v)
    sig=(r,aa,zz,s.day)
    if st.session_state.get("strategy_sig")!=sig:
        st.session_state["strategy_sig"]=sig;st.session_state.pop("strategy_output",None)
    if st.button("运行策略回测",type="primary"):
        periods=[d for d in bounds if d[0]>=aa and d[2]<=zz]
        if not periods:st.error("该区间没有完整的月度调仓样本。")
        else:
            with st.spinner("正在计算月度交易记录…"):
                try:
                    st.session_state["strategy_output"]=run(s,r,periods[0][1],periods[-1][2])
                    remember_research(periods[0][1],periods[-1][2])
                except ValueError as exc:st.error(str(exc))
    if "strategy_output" in st.session_state:
        output=st.session_state["strategy_output"];equity=output["main"]["curve"]
        first=equity[0][0];launch=s.catalog[bench][6] or ""
        values={bar[0]:bar[1] if bar[0]==first else bar[4] for bar in s.series(bench)["bars"] if bar[0]>=launch}
        common=[(d,nav,values[d]) for d,nav in equity if values.get(d) and values[d]>0]
        index_points=[(d,common[0][1]*price/common[0][2]) for d,_,price in common] if len(common)>=2 else []
        result(s,r,output,strategy_benchmark=index_points)
    else:st.caption("最早有效信号日："+iso(bounds[0][0])+"。历史从各市场实际可用的因子样本开始。")
