from dataclasses import replace
import math
from datetime import timedelta

import pandas as pd
import streamlit as st

from .comparison import CRITERIA,compare
from .frames import BENCHMARKS,MARKETS,MODELS,WEIGHTS,Rules
from .portfolio import run
from .research import codes
from .ui_common import curve,dates,day,ds,fmt,iso,label,option,pct,table

FREQ={"hold":"买入并持有","months":"每月调仓","quarter":"每季调仓","half":"每半年调仓","days":"自定义交易日数"}
DEFAULTS=("600519.SH","000001.SZ","300750.SZ")
GROUPS={"all":"全部股票模型","manual":"使用自选名单"}
ss=st.session_state


def seen_research(start,end):
    return any(a<=end and start<=z for a,z in ss.get("seen_performance_windows",[]))


def remember_research(start,end):
    history=sorted(set([*ss.get("seen_performance_windows",[]),(start,end)]))
    intervals=[]
    for a,z in history:
        if intervals and a<=intervals[-1][1]:intervals[-1]=(intervals[-1][0],max(z,intervals[-1][1]))
        else:intervals.append((a,z))
    ss["seen_performance_windows"]=intervals


def basket(s,p,locked):
    names=codes(s,"stock")
    return tuple(st.multiselect("自选股票（按名称或代码搜索，可增删）",names,default=list(DEFAULTS),
        format_func=lambda c:label(s,c),key=p+"stocks",disabled=locked,max_selections=200))


def trading(p,r,locked):
    k=option("调仓方式",FREQ,p+("freqcustom" if r.model=="manual" else "freqmodel"),"hold" if r.model=="manual" else "months",locked)
    if k=="days":
        i=int(st.number_input("每隔多少个交易日调仓",1,10000,20,key=p+"days",disabled=locked))
    else: i={"months":1,"quarter":3,"half":6,"hold":1}[k]
    return replace(r,cadence=k if k in ("hold","days") else "months",interval=i)


def equalize(keys):
    if keys:
        n=len(keys);unit=10000//n
        for i,k in enumerate(keys): ss[k]=(unit+(i<10000%n))/100


def allocation(s,p,r,locked):
    if r.weighting!="manual":return r
    members=list(r.symbols) if r.model=="manual" else list(range(1,r.count+1))
    keys=[p+"weight_"+str(c) for c in members]
    if not keys:return replace(r,weights=())
    st.button("等权分配",key="equalize_"+p,disabled=locked,on_click=equalize,args=(keys,))
    if r.model!="manual": st.caption("权重依照因子排名分配，第 1 名对应第 1 个权重。")
    weights=[]
    if not any(k in ss for k in keys):
        if r.model=="manual" and tuple(members)==DEFAULTS:
            for k,v in zip(keys,[40.,30.,30.]):ss[k]=v
        else:equalize(keys)
    for k in keys:
        if k not in ss: ss[k]=max(0.,round(100.-sum(float(ss.get(j,0.)) for j in keys if j!=k),2))
    for i in range(0,len(keys),3):
        cols=st.columns(3)
        for j,c in enumerate(members[i:i+3]):
            with cols[j]:weights.append(st.number_input((label(s,c) if r.model=="manual" else f"第 {c} 名")+" 权重（%）",0.,100.,step=1.,format="%.2f",key=keys[i+j],disabled=locked))
    total=sum(weights)
    if total>100.0000001:st.error(f"目标权重合计 {total:.2f}%，请调低至 100% 以内。")
    else:st.caption(f"目标权重合计 {total:.2f}%，计划保留现金 {max(0,100-total):.2f}%。")
    return replace(r,weights=tuple(weights))


def editor(s,p,model,base,locked):
    r=replace(base,model=model)
    a,b,c=st.columns(3)
    with a:
        if model=="manual":
            r=replace(r,count=len(r.symbols))
            st.metric("名单股票数",str(r.count))
        else:r=replace(r,count=int(st.number_input("目标持股数",1,200,10,key=p+"count",disabled=locked)))
    with b:
        r=replace(r,weighting=option("配权方式",WEIGHTS,p+("manw" if model=="manual" else "sysw"),"manual" if model=="manual" else "equal",locked))
    with c:r=trading(p,r,locked)
    if model=="pb":
        compare_options={k:MODELS[k] for k in ("mom","vol","rev")}
        r=replace(r,control=option("同池对照因子",compare_options,p+"ctrl","mom",locked))
        st.caption("低 PB 与对照模型从同一批有正 PB 且有可用因子值的股票选取；调仓日、费用和配权规则相同。")
    if model=="manual" and r.weighting=="tb":
        st.caption("名单保持不变。买入并持有仅在建仓时估算一次 TB 权重；定期调仓会用调仓前的数据重新估算。")
    return allocation(s,p,r,locked)


def setup(s,p,locked,study=False):
    c1,c2,c3=st.columns(3)
    with c1: bench=option("比较基准",BENCHMARKS,p+"benchmark","000300.SH",locked)
    with c2: fee=st.number_input("单边交易费用（基点）",min_value=0.,max_value=100.,value=10.,step=0.5,key=p+"fee",disabled=locked)
    with c3:
        if study: source=option("股票来源",GROUPS,p+"source","all",locked)
        else:source=option("选股方式",MODELS,p+"model","mom",locked)
    venue="";syms=()
    if source=="manual":syms=basket(s,p,locked)
    else:venue=option("股票范围",MARKETS,p+"exchange","",locked)
    return source,Rules(bench=bench,fee=fee,exchange=venue,symbols=syms)


def descriptor(r):
    cadence="买入并持有" if r.cadence=="hold" else f"每 {r.interval} 个交易日" if r.cadence=="days" else FREQ[{1:"months",3:"quarter",6:"half"}[r.interval]]
    return f"{MODELS[r.model]} · {r.count} 只 · {WEIGHTS[r.weighting]} · {cadence}"


def result(s,r,res,title="回测结果",strategy_benchmark=None):
    m=res["main"];rows=res["months"];end=rows[-1];mark=BENCHMARKS[r.bench]
    st.subheader(title)
    st.caption(f"实际持有区间：{iso(rows[0]['entry'])} 至 {iso(end['end'])}　·　{descriptor(r)}　·　单边 {r.fee:g} 基点")
    c=st.columns(4)
    c[0].metric("组合累计收益",pct(m["total"]))
    c[1].metric("最大回撤",pct(m["dd"]))
    c[2].metric("交易费用 / 初始资金",fmt(m["cost"],3)+"%")
    c[3].metric("调仓次数",str(sum(x["rebalance"] for x in rows)))
    names=[("组合",m)]
    if r.weighting!="equal":names.append(("同名单等权",res["equal"]))
    if "control" in res:names.append(("同池："+MODELS[r.control],res["control"]))
    lines=[(n,o["curve"]) for n,o in names]
    if strategy_benchmark is not None:
        if strategy_benchmark:lines.append((mark,strategy_benchmark))
    elif res["market"]:lines.append((mark,res["marketCurve"]))
    curve(lines,"组合与比较基准","净值（期初 = 100）",100)
    if strategy_benchmark is not None:
        if len(strategy_benchmark)>=2:
            first=strategy_benchmark[0][0]
            st.caption(f"{mark} 从 {iso(first)} 的首个可比时点与策略对齐；仅显示指数发布后有报价的日期。")
        else:st.info(f"{mark} 在该区间没有足够的可比报价。")
    elif res["market"]:
        st.caption(f"{mark} 同期收益 {pct(res['market']['total'])}。")
    elif res["overlap"]:
        q=res["overlap"]
        st.info(f"{mark} 未覆盖整个回测区间。仅在 {iso(q['from'])} 至 {iso(q['to'])} 的连续共同区间，组合收益 {pct(q['main'])}，基准收益 {pct(q['market'])}。")
    else:st.info(f"{mark} 在这段区间没有可比记录。")
    st.caption(("逐日收盘估值。" if r.daily else "按月末收盘估值；表中回撤由月末净值计算，无法反映所有月内波动。")+"收益和净值已扣除所设费用。")
    if len(names)>1:
        table([{"序列":n,"累计收益":pct(o["total"]),"最大回撤":pct(o["dd"]),"交易费用 / 初始资金":fmt(o["cost"],3)+"%"} for n,o in names])
    if res["missingFits"]:st.info("区间内没有可用的 TB 回归估计，相应资金保留现金。")
    if not any(x["held"] for x in rows):st.warning("该区间没有实际持仓，组合保持现金。请查看名单上市时间、可交易性和 TB 输入。")
    with st.expander("期末持仓与现金",expanded=True):
        st.caption(f"实际持有 {end['held']} 只，现金 {fmt(end['cash'])}%。目标权重是最近调仓指令，实际权重按期末持仓计算。")
        table([{"股票":s.catalog[h["code"]][1],"代码":h["code"],"目标权重":fmt(h["weight"])+"%","期末实际权重":fmt(h["endWeight"])+"%",
                "估值说明":"已退市、沿用最后估值" if h["ended"] else "缺少期末报价" if h["stale"] else "—"} for h in res["holdings"]])
    with st.expander("交易记录与成交口径"):
        table([{"信号日":iso(x["signal"]),"交易起日":iso(x["entry"]),"估值截止":iso(x["end"]),"调仓":"是" if x["rebalance"] else "否","候选数":x["candidates"],
                "持仓数":x["held"],"现金":fmt(x["cash"])+"%","本期收益":pct(x["ret"]),"双边换手":fmt(x["turn"])+"%"} for x in reversed(rows)])
        e=m["execution"]
        st.caption(f"有官方开盘限价记录的交易指令 {e['verified']} 笔，按历史报价估计 {e['estimated']} 笔，无有效开盘报价 {e['unquoted']} 笔。未成交资金按现金处理；缺失收盘报价按最后可用估值计算。")


def range_view(s):
    p="cfg_range_"
    source,base=setup(s,p,False)
    r=editor(s,p,source,base,False)
    d1,d2=st.columns(2)
    with d1:a=dates("回测起日",ds((day(s.day)-timedelta(days=365)).replace(day=1)),s.day,p+"a")
    with d2:b=dates("回测截止日",s.day,s.day,p+"b")
    ident=(s.day,r,a,b)
    if ss.get("range_sig")!=ident:
        ss["range_sig"]=ident;ss.pop("range_output",None)
    if st.button("运行区间回测",type="primary",key="run_interval"):
        ss.pop("range_output",None)
        with st.spinner("正在使用历史行情计算…"):
            try:
                ss["range_output"]=run(s,r,a,b)
                rows=ss["range_output"]["months"];remember_research(rows[0]["entry"],rows[-1]["end"])
            except ValueError as exc:st.error(str(exc))
    if "range_output" in ss:result(s,r,ss["range_output"])
    else:st.caption("设好参数后运行，即可查看净值、持仓、费用和逐期交易记录。")


def study_view(s):
    p="cfg_study_";locked="frozen_study" in ss
    st.caption("先用样本内数据比较候选参数，锁定排名第一的方案，再单独检验样本外表现。")
    if locked:
        st.success("方案已锁定，候选参数、评价标准和两个区间均不可更改。")
        if st.button("解锁并重新比较",key="unlock_study"):
            for key in ("frozen_study","study_train","study_review","study_test","study_sig"): ss.pop(key,None)
            st.rerun()
    source,base=setup(s,p,locked,True)
    left,right=st.columns(2)
    with left:
        st.markdown("**样本内 · 选参数**")
        a=dates("样本内起日","20100101",s.day,p+"trainA",locked)
        b=dates("样本内截止日","20191231",s.day,p+"trainB",locked)
    with right:
        st.markdown("**样本外 · 检验锁定方案**")
        c=dates("样本外起日","20200101",s.day,p+"testA",locked)
        d=dates("样本外截止日",s.day,s.day,p+"testB",locked)
    if seen_research(c,d) and "study_test" not in ss:
        st.info("本次会话已查看过与这个样本外区间重叠的业绩；可作复验，不能再将它当作完全未看过的数据。")
    left,right=st.columns(2)
    with left:count=int(st.number_input("候选方案数",2,8,2,key=p+"candidates",disabled=locked))
    with right:criterion=option("样本内评价标准",CRITERIA,p+"criterion","return",locked)
    recipes=[]
    for i in range(count):
        tag=p+str(i)+"_"
        with st.expander(f"候选 {i+1} 的参数",expanded=i<2 and not locked):
            model="manual" if source=="manual" else option("选股模型",{k:v for k,v in MODELS.items() if k!="manual"},tag+"model",["mom","vol","rev","pb"][i%4],locked)
            defaultkey=tag+("manw" if model=="manual" else "sysw")
            if model=="manual" and defaultkey not in ss: ss[defaultkey]=["equal","tb","manual"][i%3]
            recipes.append(editor(s,tag,model,base,locked))
    rules=tuple(recipes);win=(a,b,c,d);sig=(s.day,rules,win,criterion)
    if not locked and ss.get("study_sig")!=sig:
        ss["study_sig"]=sig
        for key in ("study_train","study_review","study_test"):ss.pop(key,None)
    if not locked and st.button("比较样本内表现",type="primary",key="train"):
        for key in ("study_train","study_review","study_test"):ss.pop(key,None)
        with st.spinner("只用样本内行情比较候选…"):
            try:
                ss["study_train"]=compare(s,rules,win,criterion)
                row=ss["study_train"][0][0];remember_research(row["start"],row["end"])
            except ValueError as exc:st.error(str(exc))
    if "study_train" not in ss:return
    ranking,winner=ss["study_train"]
    st.markdown("**样本内排名**")
    table([{"排名":str(j+1) if row[criterion] is not None else "不参与","候选":f"候选 {row['index']+1}","参数":descriptor(rules[row["index"]]),"扣费收益":pct(row["return"]),"月度最大回撤":pct(row["drawdown"]),
            "年化夏普":fmt(row["sharpe"],3),"完整月数":row["months"],"实际持仓":"是" if row["invested"] else "否"} for j,row in enumerate(ranking)])
    st.caption("回撤按相同的月度估值频率比较。夏普比率采用完整月份的扣费收益，月无风险利率取 0，以 √12 年化；不足两个完整月或收益无波动时不参与夏普排名。")
    if winner is None:st.warning("样本不足以计算所选评价指标，无法锁定胜出方案。");return
    st.caption(f"样本内胜出：候选 {winner+1}。评价标准：{CRITERIA[criterion]}；同分时按候选顺序。")
    if not locked:
        if st.button("锁定样本内胜出方案",key="lock_study"):
            ss["frozen_study"]=(rules[winner],win,criterion,s.day,winner);st.rerun()
        return
    chosen,saved_win,_,release,_=ss["frozen_study"]
    if release!=s.day:st.error("行情版本已变化，请解锁并重新比较。");return
    if st.button("查看胜出方案的样本内明细",key="review_study",disabled="study_review" in ss):
        with st.spinner("正在读取样本内持仓与净值…"):
            try:ss["study_review"]=run(s,chosen,saved_win[0],saved_win[1])
            except ValueError as exc:st.error(str(exc))
    if "study_review" in ss:result(s,chosen,ss["study_review"],"样本内回测结果")
    if st.button("运行样本外检验",type="primary",key="test_study",disabled="study_test" in ss):
        with st.spinner("正在独立计算样本外表现…"):
            try:
                ss["study_test"]=run(s,chosen,saved_win[2],saved_win[3])
                rows=ss["study_test"]["months"];remember_research(rows[0]["entry"],rows[-1]["end"])
            except ValueError as exc: st.error(str(exc))
    if "study_test" in ss:result(s,chosen,ss["study_test"],"样本外检验结果")
    st.caption("如果看过样本外结果后再调参数，这段区间就不再是独立检验。")


def portfolio_page(s):
    st.title("组合表现")
    st.write("构建组合，比较历史收益、回撤和持仓。")
    mode=st.radio("研究方式",["区间回测","参数比较与样本外检验"],horizontal=True,key="cfg_portfolio_tab",label_visibility="collapsed")
    if mode=="区间回测":range_view(s)
    else:study_view(s)
