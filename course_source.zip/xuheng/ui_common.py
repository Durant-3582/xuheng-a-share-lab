from datetime import date, datetime
import hashlib
import hmac
import os
import re
from pathlib import Path

import pandas as pd
import plotly.graph_objects as go
import streamlit as st

from .archive import Archive, ArchiveError

ROOT=Path(__file__).resolve().parents[1]
NAV={"overview":"市场总览","indices":"指数中心","stocks":"个股研究","factors":"因子选股","strategies":"策略回测","portfolio":"组合表现"}
COLORS=["#176552","#a66335","#465d96","#81639a","#646b6d"]
STATUS={"ready":"已有日线","empty":"未返回日线","denied":"权限受限"}


def conf(key, default=""):
    if key in os.environ:
        return os.environ[key]
    try: return st.secrets.get(key,default)
    except (FileNotFoundError,KeyError): return default


def access():
    origin=conf("XUHENG_COURSE_ORIGIN")
    origin_file=ROOT/".streamlit"/"course-origin"
    if not origin and origin_file.is_file():origin=origin_file.read_text().strip()
    if origin:
        from .course_service import redeem
        if not isinstance(origin,str) or not re.fullmatch(r"https://[a-z0-9-]+(?:\.[a-z0-9-]+)*\.chatgpt\.site",origin):
            st.error("课程服务地址配置无效。");st.stop()
        if st.session_state.get("course_cookie") and st.session_state.get("course_origin")==origin:
            return
        def unlock(code):
            try:cookie=redeem(origin,code)
            except ArchiveError as exc:st.error(str(exc));return False
            if cookie:
                st.session_state.update(course_cookie=cookie,course_origin=origin,course_code=code)
                return True
            return False
        candidate=st.query_params.get("course","")
        if candidate and unlock(candidate):return
        st.title("序衡 · A 股投研")
        st.write("打开课程专用链接，或输入课程口令进入研究工作台。")
        with st.form("course_login"):
            code=st.text_input("课程访问口令",type="password",max_chars=180)
            submit=st.form_submit_button("进入工作台",type="primary")
        if submit:
            if unlock(code):st.rerun()
            else:st.error("未能验证课程口令，请检查专用链接。")
        st.stop()
    digest=conf("XUHENG_ACCESS_SHA256")
    if not digest or len(digest)!=64:
        st.warning("课程访问口令尚未配置，请联系平台维护者。")
        st.stop()
    if hmac.compare_digest(st.session_state.get("access_grant",""),digest):
        return
    def valid(value):
        return isinstance(value,str) and len(value)<=300 and hmac.compare_digest(hashlib.sha256(value.encode()).hexdigest(),digest)
    if valid(st.query_params.get("course","")):
        st.session_state["access_grant"]=digest
        return
    st.title("序衡 · A 股投研")
    st.write("课程研究工作台。打开课程专用链接，或输入课程口令后查看。")
    with st.form("access"):
        value=st.text_input("课程访问口令",type="password",max_chars=300)
        submit=st.form_submit_button("进入工作台",type="primary")
    if submit and valid(value):
        st.session_state["access_grant"]=digest
        st.rerun()
    if submit: st.error("口令不正确，请检查是否使用了最新的课程链接。")
    st.stop()


@st.cache_resource(show_spinner=False)
def connect(directory,base,token,repo,tag):
    return Archive(directory,base,token,repo,tag)


def connection():
    if st.session_state.get("course_cookie"):
        from .course_service import CourseService
        if "course_data_service" not in st.session_state:
            st.session_state["course_data_service"]=CourseService(st.session_state["course_origin"],
                    st.session_state["course_code"],st.session_state["course_cookie"])
        return st.session_state["course_data_service"]
    return connect(conf("XUHENG_DATA_DIR",str(ROOT/".private-data")),conf("XUHENG_ARCHIVE_BASE"),conf("XUHENG_ARCHIVE_TOKEN"),
                   conf("XUHENG_GITHUB_REPO"),conf("XUHENG_GITHUB_TAG"))


def day(v):
    return datetime.strptime(v,"%Y%m%d").date()


def iso(v):
    return f"{v[:4]}-{v[4:6]}-{v[6:8]}" if v else "—"


def ds(v):
    return v.strftime("%Y%m%d")


def pct(v,n=2):
    return "—" if v is None or pd.isna(v) else f"{v:+,.{n}f}%"


def fmt(v,n=2):
    return "—" if v is None or pd.isna(v) else f"{v:,.{n}f}"


def dates(label,default,cutoff,key,disabled=False):
    return ds(st.date_input(label,day(default),min_value=date(2000,1,1),max_value=day(cutoff),format="YYYY-MM-DD",key=key,disabled=disabled))


def option(label, items, key, default=None, disabled=False):
    keys=list(items)
    return st.selectbox(label,keys,index=keys.index(default) if default in keys else 0,
        format_func=lambda k:items[k],key=key,disabled=disabled)


def curve(lines,title,yleft="",baseline=None):
    fig=go.Figure()
    for i,(label,rows) in enumerate(lines):
        if not rows: continue
        fig.add_trace(go.Scatter(x=[iso(d) for d,v in rows],y=[v for d,v in rows],name=label,
                line={"width":2.0,"color":COLORS[i%len(COLORS)]},hovertemplate="%{y:,.3f}<extra>%{fullData.name}</extra>"))
    if baseline is not None:
        fig.add_hline(y=baseline,line_width=1,line_dash="dot",line_color="#899a8b")
    fig.update_layout(height=345,margin=dict(l=10,r=14,t=12,b=15),hovermode="x unified",
                      paper_bgcolor="rgba(0,0,0,0)",plot_bgcolor="rgba(0,0,0,0)",legend=dict(orientation="h",y=-.15),
                      xaxis=dict(type="date",title=""),yaxis=dict(title=yleft,gridcolor="#e3e9e1",zeroline=False))
    st.markdown("**"+title+"**")
    st.plotly_chart(fig,use_container_width=True,config={"displaylogo":False,"scrollZoom":False},theme=None)


def table(records):
    if len(records):
        st.dataframe(pd.DataFrame(records),use_container_width=True,hide_index=True)
    else:
        st.caption("没有符合条件的记录。")


def rangebars(bars,key):
    modes={"60":"近 60 个交易日","250":"近 250 个交易日","750":"近 750 个交易日","all":"全部历史","custom":"自定义交易日数"}
    parts=st.columns([2,1])
    with parts[0]: mode=option("显示区间",modes,key+"-range","250")
    n=len(bars) if mode=="all" else int(mode) if mode.isdigit() else None
    if n is None:
        with parts[1]: n=int(st.number_input("最近多少个交易日",min_value=1,max_value=10000,value=120,key=key+"-days"))
    return bars[-n:] if bars and n else []


def label(store,c):
    return f"{store.catalog[c][1]}　{c}"
